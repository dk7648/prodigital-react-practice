import type { ApiPaginationEnvelope } from '@/types/api-envelope';
import type { PostItem } from './types';
export async function fetchPostList(page: number, pageSize: number) {
  const postResponse = await fetch(
    `${import.meta.env.VITE_BASE_API_URL}/posts?page=${page}&pageSize=${pageSize}`
  );
  const resp = (await postResponse.json()) as ApiPaginationEnvelope<PostItem>;
  if (resp.success) return resp.data;
  else throw new Error(resp.error.message);
}
