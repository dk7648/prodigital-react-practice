import { useEffect, useState } from 'react';
import type { PostItem } from '../types';
import { fetchPostList } from '../api';
import { PostCard } from './post-card';

export default function PostList() {
  const [posts, setPosts] = useState<PostItem[]>([]);
  useEffect(() => {
    fetchPostList(1, 10).then(data => {
      setPosts(data.items);
      console.log(data);
    });
  }, []);

  useEffect(() => {
    console.log(posts);
  }, [posts]);
  return (
    <div>
      {posts.map(post => {
        return (
          <PostCard
            key={post.id}
            post={post}
            isLikePending={false}
            onToggleLike={() => {}}
            likedByMe={false}
            // viewerUserId=""
          />
        );
      })}
    </div>
  );
}
