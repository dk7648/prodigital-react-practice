export default function PostWritePage() {
  return <div>게시글 작성 페이지</div>;
}
