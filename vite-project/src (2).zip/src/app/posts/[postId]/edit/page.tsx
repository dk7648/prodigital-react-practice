// src/app/posts/[postId]/edit/page.tsx
export default function PostEditPage() {
  return <div>PostEditPage</div>;
}
