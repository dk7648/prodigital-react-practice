import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from 'react-router';

//
export default function PostDetailPage() {
  const navigate = useNavigate();
  //   const location = useLocation();
  //   console.log(location);

  const params = useParams();
  console.log('params: ', params);

  const [searchParams, setSearchParams] = useSearchParams();
  console.log('searchParams: ', searchParams.get('where'));
  console.log('searchParams: ', searchParams.get('page'));
  console.log('searchParams: ', searchParams.get('limit'));
  return (
    <div>
      PostDetailPage
      <div onClick={() => setSearchParams({ where: 'news' })}>where=news</div>
      <div onClick={() => navigate(-1)}>뒤로가기</div>
    </div>
  );
}
