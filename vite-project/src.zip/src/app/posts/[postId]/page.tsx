import { useLocation, useNavigate, useParams } from 'react-router';

//
export default function PostDetailPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const params = useParams();
  console.log(params);
  console.log(location);

  return (
    <div>
      PostDetailPage
      <div onClick={() => navigate(-1)}>뒤로가기</div>
    </div>
  );
}
