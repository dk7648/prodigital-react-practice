import { useNavigate } from 'react-router';

export default function PostPage() {
  const navigate = useNavigate();

  return (
    <div>
      <h1>This is my PostPage</h1>
      <p>PostPage입니다.</p>
      {[1, 2, 3].map(id => {
        return (
          <div
            key={id}
            onClick={() =>
              navigate(`/posts/${id}`, {
                //뒤로가기 못하게 막기
                // replace: true,
                // state: {
                //   step: 1,
                //   value: '시작하기',
                //   name: '신윤수',
                // },
              })
            }
          >
            게시글-{id}
          </div>
        );
      })}
    </div>
  );
}
