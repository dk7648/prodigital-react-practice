export default function AuthLoginPage() {
  return <div className="text-blue-700">로그인 페이지</div>;
}
