export default function AuthSignUpPage() {
  return <div className="text-blue-700">회원가입 페이지</div>;
}
