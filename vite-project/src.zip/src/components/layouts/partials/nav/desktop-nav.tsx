import { Link, NavLink } from 'react-router';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
interface DesktopNavProps {
  navItems: { to: string; label: string; end?: boolean }[];
}
export default function DesktopNav({ navItems }: DesktopNavProps) {
  return (
    <>
      <nav className="ml-10 hidden items-center gap-6 md:flex">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              cn(
                'text-sm font-medium text-muted-foreground transition-colors hover:text-foreground',
                isActive && 'text-foreground text-blue-700'
              )
            }
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="ml-auto hidden items-center gap-2 md:flex">
        <Button variant="ghost" asChild>
          <Link to="/login">로그인</Link>
        </Button>
        <Button asChild>
          <Link to="/signup">회원가입</Link>
        </Button>
      </div>
    </>
  );
}
